typoo
(typoo)

sub test {
correct indent;
}

if ($test) {
incorrect indent;
}
